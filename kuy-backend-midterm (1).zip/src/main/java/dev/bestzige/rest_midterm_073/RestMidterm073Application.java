// Watchara Santawee (65130500073)
package dev.bestzige.rest_midterm_073;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestMidterm073Application {

    public static void main(String[] args) {
        SpringApplication.run(RestMidterm073Application.class, args);
    }

}
